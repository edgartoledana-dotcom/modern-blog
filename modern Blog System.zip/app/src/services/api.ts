/**
 * API Service
 * Axios configuration and HTTP request handlers
 */

import axios, { type AxiosInstance, type AxiosError, type InternalAxiosRequestConfig } from 'axios';

// API base URL - change this based on environment
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000, // 30 second timeout
});

// Request interceptor - add auth token
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: AxiosError) => {
    return Promise.reject(error);
  }
);

// Response interceptor - handle errors
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    // Handle 401 Unauthorized
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (!refreshToken) {
          throw new Error('No refresh token');
        }

        // Try to refresh token
        const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
          refreshToken,
        });

        const { accessToken } = response.data.data;
        localStorage.setItem('accessToken', accessToken);

        // Retry original request
        originalRequest.headers.Authorization = `Bearer ${accessToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        // Refresh failed, logout user
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('user');
        window.location.href = '/admin/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),

  register: (name: string, email: string, password: string, role?: string) =>
    api.post('/auth/register', { name, email, password, role }),

  logout: () => api.post('/auth/logout'),

  getProfile: () => api.get('/auth/profile'),

  updateProfile: (data: Partial<{ name: string; bio: string; avatar: string }>) =>
    api.put('/auth/profile', data),

  changePassword: (currentPassword: string, newPassword: string) =>
    api.put('/auth/change-password', { currentPassword, newPassword }),

  refreshToken: (refreshToken: string) =>
    api.post('/auth/refresh', { refreshToken }),

  getUsers: (params?: { page?: number; limit?: number; role?: string; search?: string }) =>
    api.get('/auth/users', { params }),

  updateUserStatus: (id: string, isActive: boolean) =>
    api.patch(`/auth/users/${id}/status`, { isActive }),
};

// Posts API
export const postsAPI = {
  getPosts: (params?: {
    page?: number;
    limit?: number;
    status?: string;
    category?: string;
    tag?: string;
    search?: string;
    author?: string;
    featured?: string;
    sortBy?: string;
    sortOrder?: string;
  }) => api.get('/posts', { params }),

  getPostBySlug: (slug: string) => api.get(`/posts/${slug}`),

  getPostById: (id: string) => api.get(`/posts/id/${id}`),

  createPost: (data: FormData | object) =>
    api.post('/posts', data, {
      headers: data instanceof FormData ? { 'Content-Type': 'multipart/form-data' } : {},
    }),

  updatePost: (id: string, data: FormData | object) =>
    api.put(`/posts/${id}`, data, {
      headers: data instanceof FormData ? { 'Content-Type': 'multipart/form-data' } : {},
    }),

  deletePost: (id: string) => api.delete(`/posts/${id}`),

  getFeaturedPosts: (limit?: number) =>
    api.get('/posts/featured/list', { params: { limit } }),

  getPostsByCategory: (slug: string, params?: { page?: number; limit?: number }) =>
    api.get(`/posts/category/${slug}`, { params }),

  getPostsByTag: (tag: string, params?: { page?: number; limit?: number }) =>
    api.get(`/posts/tag/${tag}`, { params }),

  getAllTags: () => api.get('/posts/tags/all'),

  toggleFeatured: (id: string, featured: boolean) =>
    api.patch(`/posts/${id}/featured`, { featured }),

  updateStatus: (id: string, status: string) =>
    api.patch(`/posts/${id}/status`, { status }),

  getRelatedPosts: (slug: string, limit?: number) =>
    api.get(`/posts/${slug}/related`, { params: { limit } }),
};

// Categories API
export const categoriesAPI = {
  getCategories: (params?: { active?: string; includeCount?: string }) =>
    api.get('/categories', { params }),

  getCategoryBySlug: (slug: string) => api.get(`/categories/${slug}`),

  createCategory: (data: {
    name: string;
    description?: string;
    image?: string;
    color?: string;
    order?: number;
    parent?: string;
  }) => api.post('/categories', data),

  updateCategory: (id: string, data: Partial<{
    name: string;
    description: string;
    image: string;
    color: string;
    order: number;
    parent: string;
  }>) => api.put(`/categories/${id}`, data),

  deleteCategory: (id: string) => api.delete(`/categories/${id}`),

  toggleStatus: (id: string, isActive: boolean) =>
    api.patch(`/categories/${id}/status`, { isActive }),

  getCategoryStats: () => api.get('/categories/stats/overview'),
};

// Upload API
export const uploadAPI = {
  uploadImage: (file: File) => {
    const formData = new FormData();
    formData.append('image', file);
    return api.post('/upload/image', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  uploadMultipleImages: (files: File[]) => {
    const formData = new FormData();
    files.forEach((file) => formData.append('images', file));
    return api.post('/upload/images', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  uploadAvatar: (file: File) => {
    const formData = new FormData();
    formData.append('avatar', file);
    return api.post('/upload/avatar', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  deleteImage: (publicId: string) =>
    api.delete(`/upload/image/${encodeURIComponent(publicId)}`),

  getImageInfo: (publicId: string) =>
    api.get(`/upload/image-info/${encodeURIComponent(publicId)}`),

  generateSignedUrl: (folder?: string) =>
    api.post('/upload/signed-url', { folder }),
};

// Subscriber API
export const subscriberAPI = {
  subscribe: (data: { email: string; name?: string; preferences?: object; source?: string }) =>
    api.post('/subscribers/subscribe', data),

  unsubscribe: (data: { email: string; token?: string }) =>
    api.post('/subscribers/unsubscribe', data),

  verifySubscription: (token: string) =>
    api.get(`/subscribers/verify/${token}`),

  getSubscribers: (params?: {
    page?: number;
    limit?: number;
    status?: string;
    search?: string;
  }) => api.get('/subscribers', { params }),

  getSubscriberStats: () => api.get('/subscribers/stats'),

  updatePreferences: (id: string, preferences: object) =>
    api.put(`/subscribers/${id}/preferences`, { preferences }),

  deleteSubscriber: (id: string) => api.delete(`/subscribers/${id}`),
};

export default api;
