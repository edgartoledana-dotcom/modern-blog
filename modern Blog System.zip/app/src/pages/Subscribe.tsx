/**
 * Subscribe Page
 * Newsletter subscription page
 */

import React, { useState } from 'react';
import { Check, Mail, Sparkles, BookOpen, Bell, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { subscriberAPI } from '@/services/api';
import SEO from '@/components/SEO';

const benefits = [
  {
    icon: BookOpen,
    title: 'Curated Content',
    description: 'Handpicked articles delivered to your inbox every week.',
  },
  {
    icon: Sparkles,
    title: 'Exclusive Insights',
    description: 'Get access to subscriber-only content and early releases.',
  },
  {
    icon: Bell,
    title: 'Stay Updated',
    description: 'Be the first to know about new features and events.',
  },
];

const testimonials = [
  {
    quote: "The Modern Blog newsletter is the highlight of my week. Always insightful and beautifully written.",
    author: "Emily R.",
    role: "Designer"
  },
  {
    quote: "I've discovered so many great articles through this newsletter. Highly recommended!",
    author: "Michael T.",
    role: "Developer"
  },
  {
    quote: "Quality content without the fluff. Exactly what I was looking for.",
    author: "Sarah L.",
    role: "Writer"
  },
];

const Subscribe: React.FC = () => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    setError('');

    try {
      await subscriberAPI.subscribe({
        email,
        name,
        source: 'landing_page'
      });
      setIsSubscribed(true);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to subscribe. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <SEO
        title="Subscribe to Our Newsletter"
        description="Join 50,000+ readers and get weekly curated stories delivered to your inbox."
        url="/subscribe"
      />

      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <section className="relative bg-gray-900 text-white py-24 overflow-hidden">
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#e1f532]/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#e1f532]/5 rounded-full blur-2xl" />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm mb-6">
                <Mail className="w-4 h-4" />
                Join 50,000+ subscribers
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 font-['Playfair_Display']">
                Stories That Inspire, <span className="text-[#e1f532]">Delivered Weekly</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8">
                Get curated articles on design, lifestyle, technology, and wellness 
                delivered straight to your inbox. No spam, unsubscribe anytime.
              </p>
            </div>
          </div>
        </section>

        {/* Subscribe Form Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              {/* Form */}
              <div>
                {isSubscribed ? (
                  <div className="bg-green-50 border border-green-200 rounded-2xl p-8 text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="w-8 h-8 text-green-600" />
                    </div>
                    <h2 className="text-2xl font-bold text-green-800 mb-2">
                      You're Subscribed!
                    </h2>
                    <p className="text-green-700 mb-4">
                      Thank you for joining our community. Check your inbox for a welcome email!
                    </p>
                    <p className="text-green-600 text-sm">
                      Don't forget to verify your email address.
                    </p>
                  </div>
                ) : (
                  <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">
                      Subscribe Now
                    </h2>
                    <p className="text-gray-600 mb-6">
                      Fill in your details below to join our newsletter.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <label
                          htmlFor="name"
                          className="block text-sm font-medium text-gray-700 mb-2"
                        >
                          Name (optional)
                        </label>
                        <Input
                          type="text"
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Your name"
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="email"
                          className="block text-sm font-medium text-gray-700 mb-2"
                        >
                          Email Address *
                        </label>
                        <Input
                          type="email"
                          id="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                          placeholder="you@example.com"
                          className="w-full"
                        />
                      </div>

                      {error && (
                        <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                          {error}
                        </div>
                      )}

                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-gray-900 text-white hover:bg-gray-800 py-6"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            Subscribing...
                          </>
                        ) : (
                          <>
                            <Mail className="w-5 h-5 mr-2" />
                            Subscribe to Newsletter
                          </>
                        )}
                      </Button>

                      <p className="text-xs text-gray-500 text-center">
                        By subscribing, you agree to our Privacy Policy. Unsubscribe anytime.
                      </p>
                    </form>
                  </div>
                )}
              </div>

              {/* Benefits */}
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-8">
                  What You'll Get
                </h2>
                <div className="space-y-6">
                  {benefits.map((benefit) => (
                    <div key={benefit.title} className="flex gap-4">
                      <div className="w-12 h-12 bg-[#e1f532]/20 rounded-xl flex items-center justify-center flex-shrink-0">
                        <benefit.icon className="w-6 h-6 text-gray-900" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 mb-1">
                          {benefit.title}
                        </h3>
                        <p className="text-gray-600 text-sm">
                          {benefit.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Trust Badges */}
                <div className="mt-10 pt-8 border-t border-gray-100">
                  <div className="flex items-center gap-6 text-sm text-gray-500">
                    <span className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      Free forever
                    </span>
                    <span className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      No spam
                    </span>
                    <span className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      Unsubscribe anytime
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">
              What Our Subscribers Say
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="bg-white p-8 rounded-2xl shadow-sm"
                >
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Sparkles key={i} className="w-4 h-4 text-[#e1f532]" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-6 italic">
                    "{testimonial.quote}"
                  </p>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {testimonial.author}
                    </p>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Subscribe;
