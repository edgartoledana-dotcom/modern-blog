/**
 * Home Page
 * Landing page with hero section, featured posts, and latest articles
 */

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, TrendingUp, Sparkles, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { postsAPI, categoriesAPI } from '@/services/api';
import type { Post, Category } from '@/types';
import BlogCard from '@/components/BlogCard';
import SEO from '@/components/SEO';

const Home: React.FC = () => {
  const [featuredPosts, setFeaturedPosts] = useState<Post[]>([]);
  const [latestPosts, setLatestPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch featured posts, latest posts, and categories in parallel
        const [featuredRes, latestRes, categoriesRes] = await Promise.all([
          postsAPI.getFeaturedPosts(3),
          postsAPI.getPosts({ limit: 6 }),
          categoriesAPI.getCategories({ includeCount: 'true' }),
        ]);

        setFeaturedPosts(featuredRes.data.data.posts || []);
        setLatestPosts(latestRes.data.data.posts || []);
        setCategories(categoriesRes.data.data.categories?.slice(0, 5) || []);
      } catch (error) {
        console.error('Error fetching home data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const heroPost = featuredPosts[0];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <>
      <SEO
        title="Modern Blog - Stories That Inspire"
        description="Discover thoughtful stories about design, lifestyle, technology, and wellness. A modern blog for curious minds."
        keywords={['blog', 'design', 'lifestyle', 'technology', 'wellness', 'stories']}
        url="/"
      />

      <div className="min-h-screen">
        {/* Hero Section */}
        {heroPost && (
          <section className="relative min-h-[90vh] flex items-center">
            {/* Background Image */}
            <div className="absolute inset-0">
              <img
                src={heroPost.featuredImage}
                alt={heroPost.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
            </div>

            {/* Content */}
            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
              <div className="max-w-2xl">
                {/* Badge */}
                <span className="inline-flex items-center gap-2 bg-[#e1f532] text-gray-900 px-4 py-2 rounded-full text-sm font-semibold mb-6">
                  <Sparkles className="w-4 h-4" />
                  Featured Story
                </span>

                {/* Title */}
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight font-['Playfair_Display']">
                  {heroPost.title}
                </h1>

                {/* Excerpt */}
                <p className="text-lg sm:text-xl text-gray-200 mb-8 leading-relaxed">
                  {heroPost.excerpt}
                </p>

                {/* Meta */}
                <div className="flex items-center gap-6 text-gray-300 mb-8">
                  {heroPost.author && (
                    <span className="flex items-center gap-2">
                      <img
                        src={heroPost.author.avatar || '/default-avatar.png'}
                        alt={heroPost.author.name}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      {heroPost.author.name}
                    </span>
                  )}
                  <span>{new Date(heroPost.publishedAt || '').toLocaleDateString()}</span>
                  <span>{heroPost.readingTime || 5} min read</span>
                </div>

                {/* CTA */}
                <Link to={`/blog/${heroPost.slug}`}>
                  <Button
                    size="lg"
                    className="bg-[#e1f532] text-gray-900 hover:bg-[#d4e82d] font-semibold px-8 py-6 text-lg group"
                  >
                    Read Article
                    <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </div>

            {/* Scroll Indicator */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
              <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center pt-2">
                <div className="w-1.5 h-3 bg-white/50 rounded-full" />
              </div>
            </div>
          </section>
        )}

        {/* Categories Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-[#e1f532]" />
                Explore Topics
              </h2>
              <Link
                to="/blog"
                className="text-gray-600 hover:text-gray-900 flex items-center gap-1 group"
              >
                View All
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  to={`/blog?category=${category.slug}`}
                  className="group relative overflow-hidden rounded-xl aspect-[4/3] bg-white shadow-sm hover:shadow-lg transition-all duration-300"
                >
                  {category.image ? (
                    <img
                      src={category.image}
                      alt={category.name}
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  ) : (
                    <div
                      className="absolute inset-0 transition-transform duration-500 group-hover:scale-110"
                      style={{ backgroundColor: category.color }}
                    />
                  )}
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                    <h3 className="font-bold text-lg">{category.name}</h3>
                    <span className="text-sm text-white/80">
                      {category.postCount || 0} articles
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Posts Section */}
        {featuredPosts.length > 1 && (
          <section className="py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-10">
                <h2 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
                  <TrendingUp className="w-8 h-8 text-[#e1f532]" />
                  Editor's Picks
                </h2>
                <Link
                  to="/blog?featured=true"
                  className="text-gray-600 hover:text-gray-900 flex items-center gap-1 group"
                >
                  View All Featured
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {featuredPosts.slice(1).map((post) => (
                  <BlogCard key={post.id} post={post} variant="featured" />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Latest Posts Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-3xl font-bold text-gray-900">Latest Stories</h2>
              <Link
                to="/blog"
                className="text-gray-600 hover:text-gray-900 flex items-center gap-1 group"
              >
                View All Articles
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {latestPosts.map((post, index) => (
                <BlogCard
                  key={post.id}
                  post={post}
                  className={index === 0 ? 'sm:col-span-2 lg:col-span-1' : ''}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter CTA Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="relative overflow-hidden rounded-3xl bg-gray-900 text-white p-12 lg:p-16">
              {/* Decorative Elements */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#e1f532]/10 rounded-full blur-3xl" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#e1f532]/5 rounded-full blur-2xl" />

              <div className="relative z-10 max-w-2xl mx-auto text-center">
                <h2 className="text-3xl lg:text-4xl font-bold mb-4 font-['Playfair_Display']">
                  Stories That Matter
                </h2>
                <p className="text-gray-400 text-lg mb-8">
                  Join 50,000+ readers who receive our weekly curated stories. 
                  No spam, just thoughtful content delivered to your inbox.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link to="/subscribe">
                    <Button
                      size="lg"
                      className="bg-[#e1f532] text-gray-900 hover:bg-[#d4e82d] font-semibold px-8"
                    >
                      Subscribe Now
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                  <Link to="/blog">
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-white/30 text-white hover:bg-white/10"
                    >
                      Explore Articles
                    </Button>
                  </Link>
                </div>

                <div className="flex items-center justify-center gap-6 mt-8 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-500 rounded-full" />
                    Free forever
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-500 rounded-full" />
                    Unsubscribe anytime
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-500 rounded-full" />
                    No spam
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;
