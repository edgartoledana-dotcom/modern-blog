/**
 * About Page
 * Information about the blog and team
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { PenLine, Users, Globe, Award, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SEO from '@/components/SEO';

const stats = [
  { label: 'Articles Published', value: '500+', icon: PenLine },
  { label: 'Monthly Readers', value: '50K+', icon: Users },
  { label: 'Countries Reached', value: '100+', icon: Globe },
  { label: 'Awards Won', value: '15+', icon: Award },
];

const values = [
  {
    title: 'Quality Content',
    description: 'We believe in creating well-researched, thoughtful content that provides real value to our readers.',
  },
  {
    title: 'Diverse Perspectives',
    description: 'We showcase a variety of voices and viewpoints to enrich the conversation.',
  },
  {
    title: 'Community First',
    description: 'Our readers are at the heart of everything we do. We listen, learn, and grow together.',
  },
  {
    title: 'Continuous Learning',
    description: 'We\'re always exploring new ideas and staying curious about the world around us.',
  },
];

const team = [
  {
    name: 'Sarah Mitchell',
    role: 'Editor in Chief',
    bio: 'Sarah has over 10 years of experience in digital publishing and is passionate about storytelling.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
  },
  {
    name: 'James Crawford',
    role: 'Senior Writer',
    bio: 'James specializes in technology and design, with a keen eye for emerging trends.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
  },
  {
    name: 'Emily Chen',
    role: 'Lifestyle Editor',
    bio: 'Emily brings warmth and authenticity to every story she tells about wellness and living well.',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
  },
  {
    name: 'Michael Torres',
    role: 'Creative Director',
    bio: 'Michael oversees the visual identity of our publication, ensuring every piece looks its best.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
  },
];

const About: React.FC = () => {
  return (
    <>
      <SEO
        title="About Us"
        description="Learn about Modern Blog - our mission, values, and the team behind the stories."
        url="/about"
      />

      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <section className="relative bg-gray-900 text-white py-24 lg:py-32 overflow-hidden">
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#e1f532]/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#e1f532]/5 rounded-full blur-2xl" />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="max-w-3xl">
              <span className="inline-block text-[#e1f532] text-sm font-semibold uppercase tracking-wider mb-4">
                Our Story
              </span>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 font-['Playfair_Display']">
                We're on a Mission to Share Stories That Matter
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                Modern Blog was founded with a simple belief: that great stories have the power 
                to inspire, educate, and transform lives. We're a community of writers, thinkers, 
                and creators dedicated to exploring the ideas that shape our world.
              </p>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="w-12 h-12 bg-[#e1f532]/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="w-6 h-6 text-gray-900" />
                  </div>
                  <p className="text-3xl lg:text-4xl font-bold text-gray-900 mb-1">
                    {stat.value}
                  </p>
                  <p className="text-gray-600 text-sm">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <span className="inline-block text-[#e1f532] text-sm font-semibold uppercase tracking-wider mb-4">
                  Our Mission
                </span>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6 font-['Playfair_Display']">
                  Inspiring Curiosity, One Story at a Time
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>
                    At Modern Blog, we believe that knowledge should be accessible, engaging, and 
                    beautifully presented. Our mission is to create content that not only informs 
                    but also inspires our readers to see the world from new perspectives.
                  </p>
                  <p>
                    We cover a wide range of topics—from design and technology to wellness and 
                    lifestyle—always with a focus on quality, depth, and authenticity. Every article 
                    we publish is carefully crafted to provide real value to our community.
                  </p>
                  <p>
                    Whether you're here to learn something new, find inspiration, or simply enjoy 
                    a good read, we're honored to be part of your journey.
                  </p>
                </div>
              </div>
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=600&fit=crop"
                  alt="Our team collaborating"
                  className="rounded-2xl shadow-2xl"
                />
                <div className="absolute -bottom-6 -left-6 bg-[#e1f532] p-6 rounded-xl shadow-lg">
                  <p className="text-2xl font-bold text-gray-900">Since 2020</p>
                  <p className="text-gray-700 text-sm">Sharing stories that matter</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-block text-[#e1f532] text-sm font-semibold uppercase tracking-wider mb-4">
                What We Stand For
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 font-['Playfair_Display']">
                Our Core Values
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value) => (
                <div
                  key={value.title}
                  className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-shadow"
                >
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {value.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-block text-[#e1f532] text-sm font-semibold uppercase tracking-wider mb-4">
                Meet the Team
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 font-['Playfair_Display']">
                The People Behind the Stories
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {team.map((member) => (
                <div
                  key={member.name}
                  className="group text-center"
                >
                  <div className="relative mb-6 overflow-hidden rounded-2xl">
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-full aspect-square object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900">{member.name}</h3>
                  <p className="text-[#e1f532] text-sm font-medium mb-2">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="relative overflow-hidden rounded-3xl bg-gray-900 text-white p-12 lg:p-16 text-center">
              {/* Decorative Elements */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#e1f532]/10 rounded-full blur-3xl" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#e1f532]/5 rounded-full blur-2xl" />

              <div className="relative z-10 max-w-2xl mx-auto">
                <h2 className="text-3xl lg:text-4xl font-bold mb-4 font-['Playfair_Display']">
                  Join Our Community
                </h2>
                <p className="text-gray-400 text-lg mb-8">
                  Subscribe to our newsletter and be the first to know about new stories, 
                  exclusive content, and special events.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link to="/subscribe">
                    <Button
                      size="lg"
                      className="bg-[#e1f532] text-gray-900 hover:bg-[#d4e82d] font-semibold px-8"
                    >
                      Subscribe Now
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                  <Link to="/contact">
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-white/30 text-white hover:bg-white/10"
                    >
                      Get in Touch
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default About;
