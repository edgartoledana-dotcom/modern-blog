/**
 * Type Definitions
 * Shared TypeScript interfaces and types
 */

import type React from 'react';

// User Types
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'editor' | 'author';
  avatar?: string;
  bio?: string;
  lastLogin?: string;
  createdAt?: string;
}

export interface AuthResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresIn: string;
}

// Category Types
export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  image?: string;
  color: string;
  isActive: boolean;
  order: number;
  postCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

// Post Types
export interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featuredImage: string;
  author: User;
  categories: Category[];
  tags: string[];
  status: 'draft' | 'published' | 'archived';
  featured: boolean;
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string[];
  canonicalUrl?: string;
  views: number;
  likes: number;
  readingTime?: number;
  publishedAt?: string;
  scheduledFor?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface PostInput {
  title: string;
  excerpt: string;
  content: string;
  featuredImage: string;
  categories: string[];
  tags: string[];
  status: 'draft' | 'published' | 'archived';
  featured: boolean;
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string;
  canonicalUrl?: string;
  scheduledFor?: string;
}

// Pagination Types
export interface Pagination {
  page: number;
  limit: number;
  total: number;
  pages: number;
}

export interface PostsResponse {
  posts: Post[];
  pagination: Pagination;
}

// Tag Type
export interface Tag {
  name: string;
  count: number;
}

// Subscriber Types
export interface Subscriber {
  id: string;
  email: string;
  name?: string;
  isActive: boolean;
  isVerified: boolean;
  preferences: {
    design: boolean;
    lifestyle: boolean;
    technology: boolean;
    wellness: boolean;
    travel: boolean;
  };
  source?: string;
  createdAt?: string;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data: T;
  code?: string;
}

// Upload Types
export interface UploadResponse {
  url: string;
  publicId: string;
  originalName?: string;
  size?: number;
}

// SEO Types
export interface SEOProps {
  title: string;
  description: string;
  keywords?: string[];
  image?: string;
  url?: string;
  type?: 'website' | 'article';
  publishedAt?: string;
  modifiedAt?: string;
  author?: string;
}

// Navigation Types
export interface NavItem {
  label: string;
  href: string;
  icon?: React.ComponentType;
}

// Stats Types
export interface DashboardStats {
  totalPosts: number;
  publishedPosts: number;
  draftPosts: number;
  totalViews: number;
  totalSubscribers: number;
  newSubscribersThisMonth: number;
}

// Form Types
export interface LoginFormData {
  email: string;
  password: string;
}

export interface RegisterFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface PostFormData {
  title: string;
  excerpt: string;
  content: string;
  featuredImage: string;
  categories: string[];
  tags: string;
  status: 'draft' | 'published' | 'archived';
  featured: boolean;
  metaTitle: string;
  metaDescription: string;
  keywords: string;
}

export interface SubscribeFormData {
  email: string;
  name?: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}
