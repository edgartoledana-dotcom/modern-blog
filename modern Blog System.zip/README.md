# Modern Blog Platform

A full-stack blog platform built with React, Node.js, Express, and MongoDB. Features a beautiful frontend, powerful admin dashboard, JWT authentication, image uploads with Cloudinary, and newsletter subscription management.

## Features

### Public Features
- **Homepage** with featured posts, latest articles, and newsletter CTA
- **Blog Listing** with search, filters, categories, and pagination
- **Individual Post Pages** with SEO optimization and social sharing
- **About Page** with team information and company stats
- **Contact Page** with form and contact information
- **Newsletter Subscription** with email verification
- **Responsive Design** that works on all devices

### Admin Features
- **Secure Authentication** with JWT tokens
- **Dashboard** with statistics and recent activity
- **Post Management** - Create, edit, delete, and publish posts
- **Category Management** - Organize posts with custom categories
- **Media Library** - Upload and manage images with Cloudinary
- **Subscriber Management** - View and export subscriber lists
- **Settings** - Profile and password management

## Tech Stack

### Frontend
- React 18 with TypeScript
- Vite for build tooling
- Tailwind CSS for styling
- shadcn/ui components
- React Router for navigation
- Axios for API requests
- react-helmet-async for SEO

### Backend
- Node.js with Express
- MongoDB with Mongoose
- JWT for authentication
- Cloudinary for image storage
- Express Validator for input validation
- Helmet for security headers
- CORS enabled

## Project Structure

```
modern-blog/
├── app/                          # Frontend React App
│   ├── src/
│   │   ├── admin/               # Admin dashboard pages
│   │   │   ├── Login.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Posts.tsx
│   │   │   ├── PostEditor.tsx
│   │   │   ├── Categories.tsx
│   │   │   ├── Media.tsx
│   │   │   ├── Subscribers.tsx
│   │   │   └── Settings.tsx
│   │   ├── components/          # Reusable components
│   │   │   ├── Navigation.tsx
│   │   │   ├── Footer.tsx
│   │   │   ├── BlogCard.tsx
│   │   │   ├── Pagination.tsx
│   │   │   └── SEO.tsx
│   │   ├── contexts/            # React contexts
│   │   │   └── AuthContext.tsx
│   │   ├── pages/               # Public pages
│   │   │   ├── Home.tsx
│   │   │   ├── Blog.tsx
│   │   │   ├── SinglePost.tsx
│   │   │   ├── About.tsx
│   │   │   ├── Contact.tsx
│   │   │   └── Subscribe.tsx
│   │   ├── services/            # API services
│   │   │   └── api.ts
│   │   ├── types/               # TypeScript types
│   │   │   └── index.ts
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   ├── index.html
│   ├── package.json
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   └── vite.config.ts
│
├── backend/                      # Backend API
│   ├── src/
│   │   ├── config/
│   │   │   ├── database.js
│   │   │   └── cloudinary.js
│   │   ├── controllers/
│   │   │   ├── auth.controller.js
│   │   │   ├── post.controller.js
│   │   │   ├── category.controller.js
│   │   │   ├── upload.controller.js
│   │   │   └── subscriber.controller.js
│   │   ├── middleware/
│   │   │   ├── auth.middleware.js
│   │   │   └── error.middleware.js
│   │   ├── models/
│   │   │   ├── User.js
│   │   │   ├── Post.js
│   │   │   ├── Category.js
│   │   │   └── Subscriber.js
│   │   ├── routes/
│   │   │   ├── auth.routes.js
│   │   │   ├── post.routes.js
│   │   │   ├── category.routes.js
│   │   │   ├── upload.routes.js
│   │   │   └── subscriber.routes.js
│   │   ├── utils/
│   │   │   └── jwt.utils.js
│   │   └── server.js
│   ├── package.json
│   └── .env.example
│
└── README.md
```

## Local Development Setup

### Prerequisites
- Node.js 18+ installed
- MongoDB (local or Atlas)
- Cloudinary account (for image uploads)

### Step 1: Clone the Repository

```bash
git clone https://github.com/yourusername/modern-blog.git
cd modern-blog
```

### Step 2: Setup Backend

```bash
cd backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit .env with your values
# MONGODB_URI=your_mongodb_connection_string
# JWT_SECRET=your_jwt_secret
# CLOUDINARY_CLOUD_NAME=your_cloud_name
# CLOUDINARY_API_KEY=your_api_key
# CLOUDINARY_API_SECRET=your_api_secret

# Start development server
npm run dev
```

The backend will run on http://localhost:5000

### Step 3: Setup Frontend

```bash
cd ../app

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit .env with your values
# VITE_API_URL=http://localhost:5000/api
# VITE_SITE_URL=http://localhost:5173

# Start development server
npm run dev
```

The frontend will run on http://localhost:5173

### Step 4: Create Admin User

Use the following demo credentials or create your own:
- Email: admin@example.com
- Password: password123

To create a new admin user, make a POST request to:
```
POST http://localhost:5000/api/auth/register
Headers: Authorization: Bearer {admin_token}
Body: {
  "name": "New Admin",
  "email": "newadmin@example.com",
  "password": "password123",
  "role": "admin"
}
```

## Deployment Guide

### 1. Database Setup (MongoDB Atlas)

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Create a free account
3. Create a new cluster (free tier available)
4. Click "Connect" and choose "Connect your application"
5. Copy the connection string
6. Replace `<password>` with your database user password

### 2. Cloudinary Setup

1. Go to [Cloudinary](https://cloudinary.com)
2. Create a free account
3. Go to Dashboard
4. Copy your Cloud Name, API Key, and API Secret

### 3. Backend Deployment (Render)

1. Go to [Render](https://render.com)
2. Create a free account
3. Click "New" → "Web Service"
4. Connect your GitHub repository
5. Configure:
   - **Name**: modern-blog-api
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Root Directory**: `backend`
6. Add Environment Variables:
   - `NODE_ENV`: production
   - `PORT`: 10000 (or any available port)
   - `MONGODB_URI`: your_mongodb_atlas_connection_string
   - `JWT_SECRET`: your_random_secret_key
   - `JWT_EXPIRES_IN`: 7d
   - `JWT_REFRESH_EXPIRES_IN`: 30d
   - `CLOUDINARY_CLOUD_NAME`: your_cloud_name
   - `CLOUDINARY_API_KEY`: your_api_key
   - `CLOUDINARY_API_SECRET`: your_api_secret
   - `FRONTEND_URL`: your_frontend_url (e.g., https://modern-blog.vercel.app)
7. Click "Create Web Service"

Your backend will be deployed at: `https://modern-blog-api.onrender.com`

### 4. Frontend Deployment (Vercel)

1. Go to [Vercel](https://vercel.com)
2. Create a free account
3. Click "Add New Project"
4. Import your GitHub repository
5. Configure:
   - **Framework Preset**: Vite
   - **Root Directory**: `app`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
6. Add Environment Variables:
   - `VITE_API_URL`: your_backend_url (e.g., https://modern-blog-api.onrender.com/api)
   - `VITE_SITE_URL`: your_frontend_url (will be assigned after deployment)
7. Click "Deploy"

Your frontend will be deployed at: `https://modern-blog.vercel.app`

### 5. Update CORS Settings

After deployment, update your backend's `FRONTEND_URL` environment variable with your actual Vercel URL.

### 6. Custom Domain (Optional)

#### Using Vercel Domain (Free)
Your site is already available at the Vercel-assigned domain (e.g., `modern-blog.vercel.app`)

#### Using Freenom (Free Custom Domain)
1. Go to [Freenom](https://freenom.com)
2. Search for a free domain (.tk, .ml, .ga, .cf, .gq)
3. Complete the registration
4. In Vercel:
   - Go to your project settings
   - Click "Domains"
   - Add your custom domain
   - Follow the DNS configuration instructions

#### Using Custom Domain with Cloudflare
1. Add your domain to Cloudflare
2. Update nameservers with your domain registrar
3. In Vercel, add your custom domain
4. In Cloudflare, add a CNAME record pointing to `cname.vercel-dns.com`
5. Enable SSL/TLS (Full or Full Strict)

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login user
- `POST /api/auth/register` - Register user (admin only)
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update profile
- `PUT /api/auth/change-password` - Change password
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - Logout user

### Posts
- `GET /api/posts` - Get all posts
- `GET /api/posts/:slug` - Get single post
- `POST /api/posts` - Create post (admin/editor)
- `PUT /api/posts/:id` - Update post (admin/editor)
- `DELETE /api/posts/:id` - Delete post (admin/editor)
- `GET /api/posts/featured/list` - Get featured posts
- `GET /api/posts/category/:slug` - Get posts by category
- `GET /api/posts/tag/:tag` - Get posts by tag

### Categories
- `GET /api/categories` - Get all categories
- `GET /api/categories/:slug` - Get single category
- `POST /api/categories` - Create category (admin/editor)
- `PUT /api/categories/:id` - Update category (admin/editor)
- `DELETE /api/categories/:id` - Delete category (admin)

### Upload
- `POST /api/upload/image` - Upload single image
- `POST /api/upload/images` - Upload multiple images
- `POST /api/upload/avatar` - Upload avatar
- `DELETE /api/upload/image/:publicId` - Delete image

### Subscribers
- `POST /api/subscribers/subscribe` - Subscribe to newsletter
- `POST /api/subscribers/unsubscribe` - Unsubscribe
- `GET /api/subscribers` - Get all subscribers (admin)
- `GET /api/subscribers/stats` - Get subscriber stats (admin)

## Environment Variables

### Backend (.env)
```
NODE_ENV=development
PORT=5000
FRONTEND_URL=http://localhost:5173

MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/modern-blog

JWT_SECRET=your-super-secret-jwt-key
JWT_EXPIRES_IN=7d
JWT_REFRESH_EXPIRES_IN=30d

CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
```

### Frontend (.env)
```
VITE_API_URL=http://localhost:5000/api
VITE_SITE_URL=http://localhost:5173
```

## SEO Features

- Dynamic meta tags for each page
- Open Graph tags for social sharing
- Twitter Card support
- JSON-LD structured data
- Canonical URLs
- Sitemap generation ready
- Semantic HTML structure

## Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Helmet.js for security headers
- CORS configuration
- Rate limiting
- Input validation
- XSS protection

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License.

## Support

For support, email hello@modernblog.com or open an issue on GitHub.

---

**Happy Blogging!** 🎉
